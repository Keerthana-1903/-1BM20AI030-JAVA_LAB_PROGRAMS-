package SQUARE;

public class square{
 int s;
 public square(int a)
 {
 this.s=a;
 }
 public int cal_square()
 {
  return s*s;
  }
}