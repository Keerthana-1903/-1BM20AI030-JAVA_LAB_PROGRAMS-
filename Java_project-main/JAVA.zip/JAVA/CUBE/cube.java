package CUBE;

public class cube{
 int s;
 public cube(int a)
 {
 this.s=a;
 }
 public int cal_cube()
 {
  return s*s*s;
  }
}